const path = require('path');

module.exports = path.dirname(process.mainModule.filename);

//  otp one
// <!-- <input type="hidden" name="_csrf" value="<%= csrfToken %>"> -->

//            <!-- <input type="text" name="role" value="<%= role %>"> --> //       