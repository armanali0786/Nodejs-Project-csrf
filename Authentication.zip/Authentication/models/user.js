const mongoose = require('mongoose');
const bcrypt =require ('bcrypt');
const { STRING } = require('sequelize');
const Schema = mongoose.Schema;

const userSchema = new Schema({
 
  email: {
    type: String,
    required: true
  }, 
  password :{
    type:String,
    required:true
  },
  role :{
    type: String
  },
  resetToken:String,
  resetTokenExpiration:Date
 
});


module.exports = mongoose.model('User', userSchema);



 //module.exports = User;
