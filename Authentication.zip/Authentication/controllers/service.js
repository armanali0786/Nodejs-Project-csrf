const Service = require('../models/service');

exports.getService =(req,res,next)=>{
    res.render('admin/service', {
        path: '/add-service',
        pageTitle: 'Add service',
});
}
exports.getSercivelist =(req,res,next)=>{
  Service.find().then(service=>{

  
res.render('admin/servicelist',{
    path:'/servicelist',
    pageTitle:'Service List',
    services:service
})
})
}
exports.postservice=(req,res,next)=>{
    const name = req.body.name;
  const number = req.body.number;
  const pickdate = req.body.pickdate;
  const location = req.body.location;
  const price = req.body.price;
  const veichelservice = req.body.veichelservice;
  const dropdate = req.body.dropdte;
  const service = new Service({
    name: name,
    number: number,
    pickdate: pickdate,
    location: location,
    price:price,
    veichelservice:veichelservice,
    dropdate:dropdate,
   
  });
  
    service.save()
    .then(result => {
      // console.log(result);
      console.log('Created Service');
      console.log(service)
      res.redirect('admin/servicelist');
    })
    .catch(err => {
      console.log(err);
    });
}
// exports.postSercivelist =(req,res,next)=>{
//   res.redirect('/admin/sevicelist',{
//       path:'/servicelist',
//       pageTitle:'Service List'
//   })
// }