const bcrypt = require('bcrypt');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const sendgridTransport = require('nodemailer-sendgrid-transport');
const { validationResult } = require('express-validator/check');
const User = require('../models/user');

const transporter = nodemailer.createTransport(
  sendgridTransport({
    auth: {
      api_key:
        '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'
    }
  })
);

exports.getLogin = (req, res, next) => {
  let message = req.flash('error');
  if (message.length > 0) {
    message = message[0];
  } else {
    message = null;
  }
  res.render('auth/login', {
    path: '/login',
    pageTitle: 'Login',
    errorMessage: message
  });
};

exports.getSignup = (req, res, next) => {
  let message = req.flash('error');
  if (message.length > 0) {
    message = message[0];
  } else {
    message = null;
  }
  res.render('auth/signup', {
    path: '/signup',
    pageTitle: 'Signup',
    errorMessage: message
  });
};
var generateOtp = 0;

exports.postLogin = (req, res, next) => {
  const email = req.body.email;
  const password = req.body.password;
  generateOtp = Math.floor(1000 * Math.random() + 9000);
  console.log("OTP ", generateOtp)
  User.findOne({ email: email })
    .then(user => {

      console.log("USER FIND :: ", user.role);

      if (!user) {
        req.flash('error', 'Invalid email or password.');
        return res.redirect('/login');
      }
      bcrypt
        .compare(password, user.password)
        .then(doMatch => {
          if (doMatch) {
            req.session.isLoggedIn = true;
            req.session.user = user;
            return req.session.save(err => {
              console.log(err);
              res.render('auth/otp', {
                role: user.role,
                pageTitle: "OTP"});
            });
          }
          req.flash('error', 'Invalid email or password.');
          res.redirect('/login');
        })
        .catch(err => {
          console.log(err);
          res.redirect('/login');
        });
    })
    .catch(err => console.log(err));
};


exports.getIndex = (req, res, next) => {
  res.redirect('/')
}
exports.postSignup = (req, res, next) => {

  const email = req.body.email;
  const password = req.body.password;
  const confirmPassword = req.body.confirmPassword;
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    console.log(errors.array());
    return res.status(422).render('auth/signup', {
      path: '/signup',
      pageTitle: 'Signup',
      errorMessage: errors.array()[0].msg
    });
  }
  bcrypt
    .hash(password, 12)
    .then(hashedPassword => {
      const user = new User({
        email: email,
        password: hashedPassword
      });
      return user.save();
    })
    .then(result => {
      console.log("under the block")
      var transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: "armanali.shaikh77@gmail.com ",
          pass: "pdvi xnyn byww mkbk"
        }
      })
      var mailOptions = {
        from: "armanali.shaikh77@gmail.com ",
        to: "gkumar545454@gmail.com ",
        subject: "Session Testing ",
        text: "Hii Session is Succcesfull"

      }
      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          console.log("Error: ", error)
        } else {
          console.log(info.response)
        }
      })
      res.redirect('/login')
    })
    .catch(err => {
      console.log(err);
    });
  //     })
  //     .catch(err => {
  //       console.log(err);
  //     });
};
exports.getOtp = (req, res) => {
  res.render('auth/otp', { pageTitle: 'otp' })
};

exports.postOtp = (req, res) => {

  const otp = Number(req.body.otp);
  const role = req.body.role;
   const email = "g@gmail.com";
//const email =req.body.email;
  console.log("OTP :: ", otp);
  console.log("Role :: ", role);
  console.log("G OTP :: ", generateOtp);


  if (generateOtp == otp) {

    // const row = User.find({ role })
    User.find({ role })
      .then(ress => {

        if (ress[0].role == "admin")
          res.render('admin/service', { pageTitle: 'ServicePage' });

        else if (ress[0].role == "customer")
          res.send("<h1>Welcome To Customer Dashboard<h1>");

        else
          res.send("NOT FOUND");

      })
      .catch(err => { console.log("ERR ROLE : ", err); })
  }
  else
    res.render('auth/otp', { pageTitle: 'otp' })
}


exports.getReset = (req, res, next) => {
  let message = req.flash('error');
  if (message.length > 0) {
    message = message[0];
  } else {
    message = null;
  }
  res.render('auth/reset', {
    path: '/reset',
    pageTitle: 'Reset Password',
    errorMessage: message
  });

}
exports.postReset = (req, res, next) => {
  crypto.randomBytes(32, (err, buffer) => {
    if (err) {
      return res.redirect('auth/reset')
    }
    const token = buffer.toString('hex');
    User.findOne({ email: req.body.email }).then(user => {
      if (!user) {
        req.flash('error', 'no account with this email')
        return res.redirect('/reset');
      }
      user.resetToken = token;
      user.resetTokenExpiration = Date.now() + 360000;
      user.save();

    }).then(result => {
      console.log("under the block")
      var transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: "armanali.shaikh77@gmail.com ",
          pass: "pdvi xnyn byww mkbk"
        }
      })
      var mailOptions = {
        from: "armanali.shaikh77@gmail.com ",
        to: "gkumar545454@gmail.com ",
        subject: "RSEST PASSWORD ",
        text: "Reset the password",
        html: `<p>Pleases click the below link click this <a href="${token}"</a></p>`

      }
      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          console.log("Error: ", error)
        } else {
          //console.log(info.response)
        }
      })
      res.redirect('/login')
    })
      .catch(err => {
        console.log(err);
      });
  })
}




exports.postLogout = (req, res, next) => {
  req.session.destroy(err => {
    console.log(err);
    res.redirect('/');
  });
};
