const express = require('express');
const { check } = require('express-validator/check');
const customerController = require('../controllers/customer');
const router = express.Router();


router.get('/cus-delete/:id', customerController.getDeleteUser);

router.get('/edit/:id', customerController.getEditUser);

router.post('/update/:id',customerController.postUpdateUser);


module.exports = router;