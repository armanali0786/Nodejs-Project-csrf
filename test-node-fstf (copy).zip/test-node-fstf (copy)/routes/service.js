const express = require('express');
const { check } = require('express-validator/check');
const serviceController = require('../controllers/service');
const router = express.Router();


router.get('/add-service', serviceController.getAddservice);
router.post('/add-service', serviceController.postAddservice);

router.get('/add-customer', serviceController.getAddCustomer);
router.post('/add-customer', serviceController.postAddCustomer);

router.get('/service-view', serviceController.getServiceview);

router.get('/userview/:roleId', serviceController.getUserview);


router.get('/ser-delete/:id', serviceController.getDeleteService);

router.get('/payment',serviceController.getPayment);
router.post('/payment',serviceController.postPayment);

// router.get('/edit-service', serviceController.getEditService);


module.exports = router;