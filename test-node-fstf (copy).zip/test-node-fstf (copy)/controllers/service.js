const bcrypt = require('bcrypt');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const sendgridTransport = require('nodemailer-sendgrid-transport');
const {check} =require('express-validator');

const User = require('../models/user');
const Service = require('../models/service');


var Publishable_Key = 'pk_test_51Mg50gSDe0wCTNeS1D9dLTi8fc1FcZxP6SRrAvmvz7rmPs9ZRqgG1cmSAgrAAYgp2FlWx8A4oO5r3PhQwasyJgyY00IGol43kz'
var Secret_Key = 'sk_test_51Mg50gSDe0wCTNeSaX9n85juh39jIu8T4ljlEX3iFULxsXRpWGSFixVZFAN4woEaRuPFFIdlg577kvszUCh0rMw500HVGWJQqk'
const stripe = require('stripe')(Secret_Key) 


// const router = require('../routes/service');

// GET ADD SERVICE

exports.getAddservice = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  const getRoleId = req.cookies.roleId;
  User.find()
  .then(result => {
      res.render('service/add-service', {
        path: 'service/add-service',
        pageTitle: 'add-service',
        roleId: getRoleId,
        errorMessege: messege,
        users: result
      });
  })
  .catch(err => {console.log("ERER : ", err);})
  // res.render('auth/add-service');
};

// POST ADD SERVICE

exports.postAddservice = (req, res, next) => {
  const { name, email, vehicleno, phoneno, pickupdate, dropdate } = req.body;
  const service = new Service({
    name: name,
    email: email,
    vehicleno: vehicleno,
    phoneno: phoneno,
    vehicleno: vehicleno,
    pickupdate: pickupdate,
    dropdate: dropdate
  })
  service.save()
  res.redirect('service-view');
}

exports.getServiceview = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  Service.find()
    .then(service => {

      res.render('service/service-view', {
        path: '/service-view',
        pageTitle: 'service-view',
        errorMessege: messege,
        services: service
      });
    })
  var transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "armanali.shaikh77@gmail.com",
      pass: "vdqrmojznlhtiibg"
    }
  });
  var mailOptions = {
     from: "armanali.shaikh77@gmail.com",
    to: "abc@gmail.com",
    // to: "armanali.shaikh77@gmail.com",
    subject: "Hello Service Add Mail,",
    text: "Thanks, Now Your Service is Added Successufully"
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log("Error: ", error)
    } else {
      console.log(info.response)
    }
  })

}

// GET ADD CUSTOMER 
exports.getAddCustomer = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  res.render('service/add-customer', {
    path: '/add-customer',
    pageTitle: 'Add Customer',
    errorMessege: messege
  });
};


// POST ADD CUSTOMER 

exports.postAddCustomer = (req, res, next) => {

  const { role,name, email,password } = req.body;
  const user = new User({
    role:role,
    name: name,
    email: email,
    password:password                                                                            
  })
  user.save()
  res.redirect('/userview/1');
}



// GET USERVIEW

exports.getUserview = (req, res, next) => {
  let messege = req.flash('error');
  if (messege.length > 0) {
    messege = messege[0];
  } else {
    messege = null;
  }
  const roleId = req.params.roleId;
  User.find()
    .then(user => {
      if (user[0].role == 2) {

        console.log("other");
      }
      else {
        res.render('service/userview', {
          path: '/userview',
          pageTitle: 'userview',
          users: user,
          roleId: roleId, 
          errorMessege: messege
        })
      }
    })
}


// DELETE service

exports.getDeleteService = (req, res, next) => {
  console.log("Service ID : ", req.params.id)
  Service.findByIdAndDelete({ _id: req.params.id })
    .then(result => {
      res.redirect('/service-view')
    })
    .catch(err => { 
      console.log("ERROER :: ", err); 
    })
};


//GET PAYMENT
exports.getPayment = (req, res, next) => {

  res.render('service/payment', {
    path: '/payment',
    pageTitle: 'Payment',
    key: Publishable_Key 
  })
}

//POST PAYMENT   
exports.postPayment = (req, res,next)=>{ 
	stripe.customers.create({ 
		email: req.body.stripeEmail, 
		source: req.body.stripeToken, 
		name: 'Arman Ali', 
		address: { 
			line1: 'isro colony', 
			postal_code: '36003', 
			city: 'ahmedabad', 
			state: 'gujarat', 
			country: 'India', 
		} 
	}) 
	.then((customer) => { 
    stripe.charges.create(
      {
        "amount": 33000,
        "currency": "usd",
        "application_fee": 100,
        "description": "Isro Colony Ahmedabad",
         customer: customer.id 
      },
    );
    
	}) 
	.then((charges) => { 
    	res.redirect('/welcome') // If no error occurs 
	}) 
	.catch((err) => { 
    	console.log("error occured", JSON.stringify(err));
		// res.send(err)	 // If some error occurs 
	}); 
};

exports.getEditService = (req, res, next) => {
  res.render('service/edit-service', {
    path: '/edit-service',
    pageTitle: 'Edit Service'

  })
};


