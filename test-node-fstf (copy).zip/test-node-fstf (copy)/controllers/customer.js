const bcrypt = require('bcrypt');
const crypto = require('crypto');

const nodemailer = require('nodemailer');

const User = require('../models/user');

exports.getDeleteUser = (req, res, next) => {
    User.findByIdAndDelete({ _id: req.params.id })
      .then(result => {
       res.redirect('/userview/1');
      })
      .catch(err => { console.log("ERROER :: ", err); })
  };

  exports.getEditUser = (req, res, next) => {
    const userId = req.params.id;
    let messege = req.flash('error');
    if (messege.length > 0) {
      messege = messege[0];
    } else {
      messege = null;
    }
    User.find({_id: userId})
    .then(result => {
        res.render('service/edit-user', {
          path: 'service/edit-user',
          pageTitle: 'Edit User',
          errorMessege: messege,
          users: result
        });
  })
}

exports.postUpdateUser=(req,res,next)=>{
  const { role, name, email,password} = req.body;
  console.log("Req.body: ",req.body);
  const user =  User({
    role,
    name,
    email,
    password

  })
  user.save()
  res.redirect('/userview/1');

}
